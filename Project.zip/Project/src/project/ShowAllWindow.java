package project;


import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ItemEvent;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EtchedBorder;

public class ShowAllWindow extends JFrame  {

    private final JPanel newRoomPanel= new JPanel ();
    private final Hotel hotelData;

    public ShowAllWindow(MenuWindow mainGUI) {
        addWindowProperty();
        hotelData= mainGUI.getHotel();
    }

    private void addWindowProperty() {
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice defaultScreen = ge.getDefaultScreenDevice();
        Rectangle rect = defaultScreen.getDefaultConfiguration().getBounds();
        int x = (int) rect.getMaxX() - this.getWidth();
        int y = (int) rect.getMaxY() - this.getHeight();
        this.setLocation(x, y);
        setTitle ("Show all");
        setSize ((int)rect.getMaxX(),250);
        setVisible(false);
        revalidate();
    }
    
    public void newInitialContentPane (){
        getContentPane().removeAll();
        newRoomPanel.setLayout(new GridLayout(0, 1));
                
        JLabel instruction = new JLabel ("Choose what you would like to view");
        instruction.setFont(new Font("serif", Font.PLAIN, 40));
        newRoomPanel.add(instruction);
        instruction.setHorizontalAlignment(SwingConstants.CENTER);

        ButtonGroup jbGroup= new ButtonGroup ();
        JRadioButton guestsList = new JRadioButton ("Show all guests in the hotel");
        guestsList.setFont(new Font("serif", Font.PLAIN, 30));
        guestsList.addItemListener((ItemEvent event) -> {
            int state = event.getStateChange();
            if (state == ItemEvent.SELECTED) {
                JOptionPane.showMessageDialog(null, hotelData.getGuestsInHotel().toString(), "Show all guests", JOptionPane.INFORMATION_MESSAGE);
                jbGroup.clearSelection();
            }
        });
        guestsList.setBorder(BorderFactory.createEmptyBorder(30, 0, 0, 0));
        JRadioButton roomsList = new JRadioButton ("Show all guests sorted by room");
        roomsList.setFont(new Font("serif", Font.PLAIN, 30));
        roomsList.addItemListener((ItemEvent event) -> {
            int state = event.getStateChange();
            if (state == ItemEvent.SELECTED) {
                JOptionPane.showMessageDialog(null, hotelData.showGuestsByRoom(), "Show guests by rooms", JOptionPane.INFORMATION_MESSAGE);
                jbGroup.clearSelection();
            }
        });
        JRadioButton pastGuestsList = new JRadioButton ("Show all past guests of the hotel");
        pastGuestsList.setFont(new Font("serif", Font.PLAIN, 30));
        pastGuestsList.setBorder(BorderFactory.createEmptyBorder(10, 0, 30, 0));
        pastGuestsList.addItemListener((ItemEvent event) -> {
            int state = event.getStateChange();
            if (state == ItemEvent.SELECTED) {
                JOptionPane.showMessageDialog(null, hotelData.pastGuests, "Show past guests", JOptionPane.INFORMATION_MESSAGE);
                jbGroup.clearSelection();
            }
        });
        jbGroup.add(guestsList);
        jbGroup.add(roomsList);
        jbGroup.add(pastGuestsList);
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        buttonPanel.add(guestsList);
        buttonPanel.add(roomsList);
        buttonPanel.add(pastGuestsList);
        buttonPanel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        
        newRoomPanel.add(buttonPanel);
        
        setContentPane(newRoomPanel);
        revalidate();
        
    }
}
        