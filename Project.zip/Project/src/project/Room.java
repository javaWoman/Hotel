package project;

import java.io.Serializable;
import javax.swing.JOptionPane;

public class Room implements Serializable{
    
    public int roomNumber;
    protected double fee;
    protected GuestsInRoomListChronologically guestList;

    public Room (int roomNumber, double fee){
        this.roomNumber =roomNumber;
        this.fee = fee;
        this.guestList=new GuestsInRoomListChronologically();
    }
    
    public boolean addGuestToRoom (Guest guestIn){
        if (guestList.add(guestIn)==false){
            JOptionPane.showMessageDialog(null, "Cannot add guest");
            return false;
        }
        return true;
    }
    
    public void removeGuest (String surname, String name){
        guestList.remove(surname, name);
    }
    
    public void changeFee (double newPrice){
        fee = newPrice;
    }

    public String getRoomNumberInString (){
        return String.valueOf(roomNumber);
    }
    
    public String getRoomFeeInString (){
        return Double.toString(fee);
    }
    
    public double getFee (){
        return fee;
    }
    
    public int getRoomNumber(){
        return roomNumber;
    }

    public GuestsInRoomListChronologically getGuestList (){
        return guestList;
    }
    
    @Override
    public String toString (){
        return "Room number: "+roomNumber +"\n";
    }
}
