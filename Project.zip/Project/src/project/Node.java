package project;

import java.io.Serializable;

public class Node implements Serializable{
    Guest data;
    Node next;
    
    public Node (Guest data, Node next){
        this.data=data;
        this.next=next;
    }
    public Node (Guest data){
        this.data=data;
        this.next=null;
    }
    public void setNext (Node next){
        this.next=next;
    }
    public Node getNext (){
        return next;
    }
    public Guest getGuest (){
        return data;
    }
    
}
