package project;

import java.io.Serializable;

public class GuestInHotelListAlphabetical implements Serializable{ 

    Node head=null;
    Node tail=null;
    
    public GuestInHotelListAlphabetical (){
    }
    
    public boolean addGuest(Guest nGuest){
        if (head==null){
            this.head= new Node(nGuest);
            tail=head;
            return true;
        }
        if (nGuest.getSurname().compareTo(head.getGuest().getSurname())<0){
            Node previousHead = head;
            head=new Node (nGuest, previousHead);
            return true;
        }
        if (nGuest.getSurname().compareTo(head.getGuest().getSurname())>0){
            Node current=head;
                while (current.getNext()!=null && 
                        current.getNext().getGuest().getSurname().compareTo(nGuest.getSurname())<0){
                    current=current.getNext();
                }
                Node temp = current.getNext();
                current.setNext(new Node (nGuest,temp));
                return true;
        }
        if (nGuest.getSurname().compareTo(head.getGuest().getSurname())==0){
            if (nGuest.getName().compareTo(head.getGuest().getName())>0){
            Node current=head;
                while (current.getNext()!=null && 
                        current.getNext().getGuest().getName().compareTo(nGuest.getName())<0){
                    current=current.getNext();
                }
                Node temp = current.getNext();
                current.setNext(new Node (nGuest,temp));
                return true;
            } else {
            Node previousHead = head;
            head=new Node (nGuest, previousHead);
            return true;
            }
        }
        return false;
    }
    public Guest remove (String surname, String name){
        Node foundGuest= findGuest(surname,name);
        Guest result=null;
        if (foundGuest==null){
            return result;
        }
        if (head==foundGuest){
            if (head.getNext()==null){
                result = head.getGuest();
                head=null;
                return result;
            } else {
                result = head.getGuest();
                head=head.getNext();
                return result;
            }
        } else {
            Node current=head;
            while(current.getNext()!=foundGuest){
                current=current.getNext();
            }
            result = current.getNext().getGuest();
            current.setNext(current.getNext().getNext());
            return result;
        }
    }
    
    private Node findGuest (String surname, String name){
        Node current= head;
            while(current!=null){
                if (current.getGuest().getSurname().equalsIgnoreCase(surname)&&
                        current.getGuest().getName().equalsIgnoreCase(name)){
                    return current;
                } 
                current=current.getNext();
            }
        return null;
        }
    
    public Node getHead (){
        return head;
    }
    @Override
    public String toString (){
        String result="";
        if (head==null){
            result = "No guests to show";
        } else {
            Node current=head;
            while (current!=null){
                result= result + current.getGuest().getSurname()+ " " + current.getGuest().getName()
                        + " "+ current.getGuest().getReservationDates()+ 
                        "Room: "+current.getGuest().getRoom().getRoomNumberInString()+"\n";
                current=current.getNext();
            }
        }
        return result;
    }

}
