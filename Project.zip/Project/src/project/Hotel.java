package project;

import java.io.Serializable;
import javax.swing.JOptionPane;

public class Hotel implements Serializable {
    
    protected GuestInHotelListAlphabetical guestsInHotel=null;
    protected Room [] roomArray=null;
    protected GuestInHotelListAlphabetical pastGuests=null;
    private int numGuests;
    private int maxRooms=0;
    private int numRooms;
    
    public Hotel (){
        guestsInHotel = new GuestInHotelListAlphabetical();
        pastGuests = new GuestInHotelListAlphabetical ();
        numGuests=0;
        numRooms=0;
    }
    public void addRooms (int maxRooms){
        this.maxRooms= maxRooms;
        roomArray = new Room [maxRooms];
    }
    public void addGuest (Guest nGuest){
            guestsInHotel.addGuest(nGuest);
            numGuests++;
    }
    public Guest findGuest (String surname,String name){
        Node temp = guestsInHotel.getHead();
        for (int i=0; i<numGuests; i++) {
            if (temp.getGuest().getSurname().equalsIgnoreCase(surname)&&
                temp.getGuest().getName().equalsIgnoreCase(name)) {                
                return temp.getGuest();
            } else {
                temp= temp.getNext();
            }
        }
        return null;
    }
    public Room findRoom (int search){
        for (Room roomArray1 : roomArray) {
            if (roomArray1.roomNumber == search) {
                return roomArray1;
            }
        }
        return null;
    }
    public void addRoom (Room nRoom){
        roomArray [numRooms++]= nRoom;
    }
    public String showRoomArray(){
        String rooms="";
        for (int i=0; i<maxRooms;i++){
            rooms = rooms + "Room: "+ roomArray[i].getRoomNumberInString()+" for "
                    + roomArray[i].getRoomFeeInString()+"PLN\n";
        }
        return rooms;
    }
    public String showGuestsByRoom (){
        String rooms="";
        for (int i=0; i<maxRooms;i++){
            rooms = rooms + "Room: "+ roomArray[i].getRoomNumberInString()+"\n"
                    +roomArray[i].getGuestList().toStringWithoutRoomNumber()+"\n";
        }
        return rooms;
    }
    public int getNumberOfGuests (){
        return numGuests;
    }
    public GuestInHotelListAlphabetical getGuestsInHotel (){
        return guestsInHotel;
    }
    public void checkOutGuest (String surname, String name){            
            Guest foundGuest = guestsInHotel.remove(surname,name);
            if (foundGuest!=null){
            pastGuests.addGuest(foundGuest);
            foundGuest.getRoom().removeGuest(surname, name);
            JOptionPane.showMessageDialog(null, "You have successfully checked out the guest", "Successful check out", JOptionPane.INFORMATION_MESSAGE);
            }
    }      
    public Room[] getRoomArray(){
        return roomArray;
    }
    @Override
    public String toString (){
        return showRoomArray ();
    }
    public String showRoomFees(){
        String rooms = "";
        for( int i=0; i<numRooms; i++){
            rooms  = rooms+ "Room number: "+ roomArray[i].getRoomNumberInString()+" Fee: "+roomArray[i].getFee()+"\n";
        }
        return rooms;
    }
    public void cancelReservation (String surname, String name){
        Guest foundGuest = guestsInHotel.remove(surname, name);
        if (foundGuest!=null){
            foundGuest.getRoom().removeGuest(surname, name);
            JOptionPane.showMessageDialog(null, "You have successfully cancelled the reservation", "Successful cancellation", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
