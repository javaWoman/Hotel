package project;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;

public class ActionListenerComboBoxOfRooms implements ActionListener{
    
    private JComboBox jbc;
    private final Hotel hotelData;
    protected Room theRoom;
    
    public ActionListenerComboBoxOfRooms (JComboBox jbc, MenuWindow mainGUI){
        hotelData = mainGUI.getHotel();
        this.jbc=jbc;
        this.theRoom=hotelData.findRoom(1);
    }
    
    public Room returnTheRoom (){
        return theRoom;
    }
        
    public int getRoomNumber (){
        return theRoom.getRoomNumber();
    }
    
    public String getRoomNumberInString (){
        return theRoom.getRoomNumberInString();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        jbc = (JComboBox)e.getSource();
            int numberOfItems = (int)jbc.getItemCount();
            for (int i=0; i<=numberOfItems; i++){
                if (jbc.getSelectedIndex()+1==i){
                    theRoom = hotelData.findRoom(i);
                }
            } 
        }
    }
