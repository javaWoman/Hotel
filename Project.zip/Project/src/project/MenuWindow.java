package project;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public final class MenuWindow extends JFrame implements ActionListener {
    
    private final CheckInWindow checkInWindow;
    private final ShowAllWindow showAllWindow;
    private final CheckOutWindow checkOutWindow;
    private final CancelReservationWindow cancelWindow;
    private final StartWindow startWindow;
    private JButton jb = null;
    private final Hotel hotelData;
    private final Font mainFont = new Font("serif", Font.PLAIN, 40);

    public MenuWindow (StartWindow startWindow){
        this.startWindow=startWindow;  
        hotelData = startWindow.getNewHotel();
        checkInWindow = new CheckInWindow (this);
        showAllWindow = new ShowAllWindow (this);
        checkOutWindow = new CheckOutWindow (this);
        cancelWindow = new CancelReservationWindow (this);
    }
    //assigns properties to the MainActionWindow
    public void addPropertiesandRun() {
        JPanel mainButtonPanel = new JPanel ();
        addButtons (mainButtonPanel);   
        setTitle ("Hotel Manager");
        setResizable(false);
        setUndecorated(true);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        getContentPane().add(mainButtonPanel);
        setSize((int)Toolkit.getDefaultToolkit().getScreenSize().getWidth(),115);
        setVisible(true);
    }
    //creates and adds buttons to the MainActionWindow
    private void addButtons (JPanel mainButtonPanel) {
        mainButtonPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JButton in = new JButton("Check in guest");
        in.addActionListener(this);
        in.setFont(mainFont);
        
        JButton all = new JButton("Show all");
        all.addActionListener(this);
        all.setFont(mainFont);

        JButton out = new JButton("Check out guest");
        out.addActionListener(this);
        out.setFont(mainFont);
        
        JButton cancel = new JButton("Cancel");
        cancel.addActionListener(this);
        cancel.setFont(mainFont);
        
        JButton change = new JButton ("Change room fees");
        change.addActionListener(this);
        change.setFont(mainFont);        
        
        JButton exit = new JButton ("Exit");
        exit.addActionListener(this);
        exit.setFont(mainFont);

        mainButtonPanel.add(in,gbc);
        mainButtonPanel.add(all, gbc);
        mainButtonPanel.add(out, gbc);
        mainButtonPanel.add(cancel, gbc);
        mainButtonPanel.add(change,gbc);
        mainButtonPanel.add(exit,gbc);
    }

    public JFrame getCheckInWindow (){
        return checkInWindow;
    }
    public JFrame getShowAllRoomsWindow(){
        return showAllWindow;
    }
    public JFrame getCheckOutWindow (){
        return checkOutWindow;
    }
    public StartWindow getStartWindow (){
        return startWindow;
    }
    public Hotel getHotel (){
        return hotelData;
    }
    //allows user to change the fee charged for staying in a specific rooms
    public void changeRateButton (Hotel hotelData){
        JOptionPane.showMessageDialog(null,"These are the current room fees:\n"+hotelData.showRoomFees());
        int numberToSeek= JOptionPane.showOptionDialog(null, "Input number of the room, the fee of which you wish to alter", 
                "Number of room", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,null,null,null);
        if (numberToSeek == JOptionPane.CANCEL_OPTION || numberToSeek == JOptionPane.CLOSED_OPTION){
        } else {
            String numberToSeekString =JOptionPane.showInputDialog("Input number of the room, "
                    + "the fee of which you wish to alter");
            if(numberToSeekString==null) {
            } else {
                try {
                    numberToSeek= Integer.parseInt(numberToSeekString);
                    Room roomFound=hotelData.findRoom(numberToSeek);
                    if (roomFound==null){
                        JOptionPane.showMessageDialog(null, "Sorry. Such room does not exist. "
                                + "Please try again");
                    } else{
                        numberToSeek=Integer.parseInt(numberToSeekString);
                        int feeToChange = Integer.parseInt(JOptionPane.showInputDialog("Input new fee for room "+
                                numberToSeek));
                        roomFound.changeFee(feeToChange);
                        while (JOptionPane.showConfirmDialog(null,"These are now the current room fees:\n"+
                                hotelData.showRoomFees(),"New room fees",JOptionPane.YES_NO_OPTION)==JOptionPane.NO_OPTION){
                            numberToSeek=Integer.parseInt(JOptionPane.showInputDialog(null, "Input number of room "
                                    + "the fee of which you wish to alter"));
                            roomFound=hotelData.findRoom(numberToSeek);
                            feeToChange = Integer.parseInt(JOptionPane.showInputDialog("Input new fee for room "+numberToSeek));
                            roomFound.changeFee(feeToChange);
                        }
                    }
                } catch (NumberFormatException e){
                    JOptionPane.showMessageDialog(null, "Please provide valid information to proceed. Try again", 
                            "Error whilst changing room fee", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }         

    @Override
    public void actionPerformed (ActionEvent ae) {
        jb = (JButton)ae.getSource();
        switch (ae.getActionCommand()) {
            case "Check in guest":
                checkInWindow.setVisible(true);
                break;
            case "Show all":
                showAllWindow.newInitialContentPane();
                showAllWindow.setVisible(true);
                break;
            case "Check out guest":
                checkOutWindow.setVisible(true);
                if (hotelData.getNumberOfGuests()==0){
                    JOptionPane.showMessageDialog(checkOutWindow, 
                            "Sorry there is currently noone to check out", "Empty Hotel", JOptionPane.ERROR_MESSAGE);
                    checkOutWindow.setVisible(false);
                } 
                break;
            case "Cancel":
                cancelWindow.setVisible(true);
                if (hotelData.getNumberOfGuests()==0){
                    JOptionPane.showMessageDialog(cancelWindow, 
                            "Sorry there are currently no reservations in the hotel", "Empty Hotel", JOptionPane.ERROR_MESSAGE);
                    cancelWindow.setVisible(false);
                }
                break;
            case "Change room fees":
                changeRateButton (startWindow.getNewHotel());
                break;
            case "Exit":
                try {
                    ObjectsInFile.writeObject("hotelData.ppp", hotelData);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "The hotel could not be saved", "Error whilst saving",
                            JOptionPane.ERROR_MESSAGE);
                    }
                System.exit(0);
            default:
                break;
        }
    }
}
