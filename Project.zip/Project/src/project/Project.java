package project;

import java.io.IOException;

public class Project {
    
    public static void main(String[] args) throws IOException {
        /*creates the first window where a user chooses whether
        they want to open a file with existing hotel data
        or create a new file and overwrite any existing data file
        */
        StartWindow startW= new StartWindow ();
        startW.addPropertiesAndRun();

    }
    
}
