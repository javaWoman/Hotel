package project;

import java.io.Serializable;
import java.text.DateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Guest extends Person implements Serializable{
    protected Date checkIn;
    protected Date checkOut;
    protected Room inRoom;

    public Guest (String name, String surname){
        super (name,surname);
        this.checkIn=null;
        this.checkOut=null;
        this.inRoom=null;
    }
    
    public void addRoomToGuest (Room inRoom){
        this.inRoom=inRoom;
    }
    public void setReservationDates (Date checkInDate, Date checkOutDate){
        this.checkIn=checkInDate;
        this.checkOut=checkOutDate;
    }
    public String getReservationDates (){
        DateFormat format = DateFormat.getDateInstance();
        String checkInDate= format.format(checkIn);
        String checkOutDate= format.format(checkOut);        
        return " || Check-in: "+ checkInDate + " Check-out: "+checkOutDate+" || ";
    }
    public Date getCheckInDate() {
        return checkIn;
    }
    public Date getCheckOutDate(){
        return checkOut;
    }
    public Room getRoom (){
        return inRoom;
    }
    public String showGuestInfo (){
        return name + " "+ surname +  " "+ getReservationDates() + " "+ inRoom;
    }
    public double getFee(){
        long difference = getCheckOutDate().getTime() - getCheckInDate().getTime();
        float daysTheGuestIsStayingFor = TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)+1;
        return daysTheGuestIsStayingFor*inRoom.getFee();
    }
    @Override
    public String toString (){
        return inRoom+ "\n";
    }
    public int compare (Guest g){
        if (this.surname.compareTo(g.surname)<0){
            return -1;
        }
        else if (this.surname.compareTo(g.surname)==0){
            if (this.name.compareTo(g.name)<0){
                return -1;
            }
            else if (this.name.compareTo(g.name)>0){
                return 1;
            }
            else if (this.name.compareTo(g.name)==0){
                return 0;
            }
        }
        else if (this.surname.compareTo(g.surname)>0){
            return 1;
        }
        return -999;
    }
}
