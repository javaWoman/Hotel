package project;

import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import javax.swing.JOptionPane;

public class ObjectsInFile implements Serializable{

    public ObjectsInFile() {
        
    }
    
    public static void writeObject (String name, Object objectToSave) throws FileNotFoundException, IOException{
        try (OutputStream file = new FileOutputStream(name);
            OutputStream buffer = new BufferedOutputStream(file);
            ObjectOutput output = new ObjectOutputStream(buffer);
            ){
            output.writeObject(objectToSave);
        }   catch(IOException ex){
            JOptionPane.showMessageDialog(null, "Couldn't save file"+ex.getMessage());
        }        
    }
    
    public static Hotel readObject (String name) throws FileNotFoundException, IOException, ClassNotFoundException {
        FileInputStream fis = new FileInputStream(name);
        ObjectInputStream ois = new ObjectInputStream(fis);
        Hotel hotel = (Hotel)ois.readObject();
        ois.close();
        fis.close();
        return hotel;
    }
}
