package project;

import java.io.Serializable;

public abstract class Person implements Serializable{
    protected String name;
    protected String surname;
    
    public Person (String name, String surname){
        this.name=name;
        this.surname=surname;
    }
    public Person (){     
    }
    
    public void addData (String name, String surname){
        this.name=name;
        this.surname=surname;
    }
    public String getName (){
        return name;
    }
    public String getSurname (){
        return surname;
    }
    public String toString (){
        return name + surname;
    }
}
