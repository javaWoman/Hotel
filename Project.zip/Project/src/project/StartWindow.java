package project;

import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public final class StartWindow implements ActionListener {
    private MenuWindow mainActionWindow;
    public JFrame startWindow;
    private JButton jb;
    private final Font mainFont = new Font("serif", Font.PLAIN, 40);
    protected Hotel newHotel;
    
    public StartWindow (){
        this.startWindow= new JFrame ();
        newHotel= new Hotel ();
    }
    //assigns properties to the first window
    public void addPropertiesAndRun (){
        startWindow.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        startWindow.setSize(850,300);
        startWindow.setLocationRelativeTo(null);
        startWindow.setTitle("Welcome!");
        startWindow.getContentPane().setLayout(new BoxLayout (startWindow.getContentPane(), BoxLayout.Y_AXIS));
        addButtons(startWindow);
        startWindow.setResizable(false);
        startWindow.validate();
        startWindow.setVisible(true);
    }
    //adds the buttons to the first window
    private void addButtons (JFrame startWindow){
        JPanel newPanel = new JPanel ();
        JLabel question = new JLabel ("<html><p><center>Welcome to your hotel system.</p></center>Choose one of the options below to continue.</p></html>");
        question.setAlignmentX(Component.CENTER_ALIGNMENT);
        question.setBorder(BorderFactory.createEmptyBorder(20, 5, 10, 5));
        question.setFont(mainFont);
        JButton newHotelOp = new JButton ("NEW FILE");
        newHotelOp.setFont(mainFont);
        newHotelOp.addActionListener(this);
        JButton oldHotel = new JButton ("EXISTING FILE");
        oldHotel.setFont(mainFont);
        oldHotel.addActionListener(this);
        newPanel.add(question);
        newPanel.add(newHotelOp);
        newPanel.add(oldHotel);        
        startWindow.setContentPane(newPanel);
    }
    //method by which the user specifies the number of rooms in a new hotel
    private void inputMaxHotelData (){
        int roomsNumber=0;
        int cost;
        boolean success=false;
        while (success==false){
            try {
                roomsNumber = Integer.parseInt(JOptionPane.showInputDialog(null, 
                        "How many rooms are available at the hotel? Mind that 1 person for 1 room only",
                        "Room number",JOptionPane.INFORMATION_MESSAGE));
                success=true;
                } catch (NumberFormatException n2){
                    JOptionPane.showMessageDialog(startWindow, 
                            "Sorry. To set up a hotel, you need to provide this information", 
                            "Error whilst setting up",JOptionPane.ERROR_MESSAGE);
            }
        }
        success=false; 
        newHotel.addRooms(roomsNumber);
        for (int i=1; i<roomsNumber+1; i++){
            while (success==false){
                try{
                cost=Integer.parseInt(JOptionPane.showInputDialog(startWindow,
                        "How much does staying in room " +i+" cost?"));
                Room one = new Room (i,cost);
                newHotel.addRoom(one);
                success=true;
                } catch (NumberFormatException n2){
                    JOptionPane.showMessageDialog(startWindow, 
                            "Sorry. To set up a hotel, you need to provide this information", 
                            "Error whilst setting up",JOptionPane.ERROR_MESSAGE);
                }
            }
            success=false;
        }
        JOptionPane.showMessageDialog(startWindow, "Your hotel is now all set up!\n"+
                newHotel.showRoomArray(),"Hotel setup is finished",JOptionPane.PLAIN_MESSAGE);    
    }
    //changes the visibility of the first window
    public void setVisible(boolean b) {
        startWindow.setVisible(b);
    }
    //gets the Hotel variable created in this class to be modified in other classes
    public Hotel getNewHotel (){
        return newHotel;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        jb= (JButton)e.getSource();
        switch (jb.getActionCommand()){
            case "NEW FILE":
                JOptionPane.showMessageDialog(startWindow, "To set up a new hotel, input some basic informtion", 
                        "New Hotel", JOptionPane.INFORMATION_MESSAGE);
                inputMaxHotelData();               
                startWindow.setVisible(false);
                mainActionWindow= new MenuWindow(this);
                mainActionWindow.addPropertiesandRun();
            break;
            case "EXISTING FILE":
                try {
                    newHotel = ObjectsInFile.readObject("hotelData.ppp");
                    startWindow.setVisible(false);
                    this.mainActionWindow= new MenuWindow(this);
                    mainActionWindow.addPropertiesandRun();
                }  catch (IOException | ClassNotFoundException f) {
                    JOptionPane.showMessageDialog(startWindow, "No hotel has been found to edit", 
                            "No hotel found", JOptionPane.INFORMATION_MESSAGE);
                    JOptionPane.showMessageDialog(startWindow, "To set up a new hotel, input some basic informtion", 
                            "New Hotel", JOptionPane.INFORMATION_MESSAGE);
                    inputMaxHotelData();
                    startWindow.setVisible(false);
                    mainActionWindow= new MenuWindow(this);
                    mainActionWindow.addPropertiesandRun();
                    }              
            break;
                default:
            break;
        }
    }   
}
