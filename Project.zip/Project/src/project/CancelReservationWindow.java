package project;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EtchedBorder;

public final class CancelReservationWindow extends JFrame implements ActionListener{
    
    private final Dimension checkInWindow;
    private JButton jb;
    private final Hotel hotelData;
    private final Font mainFont = new Font ("serif",Font.PLAIN,40);
    private final Font inputFont = new Font ("serif",Font.PLAIN,30);
    private JTextField surnameOutField;
    private JTextField nameOutField;
    private String guestSurname;
    private String guestName;
    
    public CancelReservationWindow (MenuWindow mainGUI){
        this.hotelData=mainGUI.getHotel();
        this.checkInWindow=mainGUI.getCheckInWindow().getSize();
        addWindowProperties();
    }
    
    private void addWindowProperties (){
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        setSize(checkInWindow);
        setLocationRelativeTo(null);
        setVisible(false);
        setTitle("Check out guest");
        setFirstCheckOutWindowProperties();
    }
    
    private void setFirstCheckOutWindowProperties (){
        getContentPane().removeAll();
        
        surnameOutField = new JTextField ("Input surname here");
        nameOutField = new JTextField ("Input name here");
        
        JLabel question1 = new JLabel();
        question1.setText("And their surname?");
        question1.setFont(new Font("serif", Font.PLAIN, 30));
        question1.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        question1.setAlignmentX(Component.CENTER_ALIGNMENT);
       
        JLabel question2 = new JLabel ();
        question2.setText("What is the name of the guest whose reservation you would like to cancel?");
        question2.setFont(new Font("serif", Font.PLAIN, 30));
        question2.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        question2.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JPanel newPanel = new JPanel ();
        JPanel tempPanel = new JPanel ();
        JPanel buttonPanel = new JPanel ();
        newPanel.setLayout(new GridLayout (0,1));
        JButton next = new JButton ("NEXT");
        next.addActionListener(this);
 
        surnameOutField.setBounds(1, 1, 150, 50);
        surnameOutField.setFont(inputFont);
        surnameOutField.setForeground(Color.GRAY);
        
        nameOutField.setBounds(1, 1, 150, 50);
        nameOutField.setFont(inputFont);
        nameOutField.setForeground(Color.GRAY);
        
        next.setFont(mainFont);
        tempPanel.setLayout(new BoxLayout(tempPanel, BoxLayout.Y_AXIS));
        getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        tempPanel.add(question2);
        tempPanel.add(nameOutField);
        tempPanel.add(question1);
        tempPanel.add(surnameOutField);
        tempPanel.setBorder(BorderFactory.createEmptyBorder(50,5,0,5));
        
        buttonPanel.add(next);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(60,5,80,5));
        newPanel.add(tempPanel);
        newPanel.add(buttonPanel);
        setContentPane(newPanel);
        revalidate();
    }
    
    private void setSecondCheckOutWindowProperties (){
        getContentPane().removeAll();
        
        JPanel secondPanel = new JPanel ();
        secondPanel.setLayout(new BoxLayout(secondPanel, BoxLayout.Y_AXIS));
        secondPanel.setBorder(BorderFactory.createEmptyBorder(50,0,0,0));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel question = new JLabel ("Is this the person you want to check out?");
        question.setBorder(BorderFactory.createEmptyBorder(0,0,20,0));
        question.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel nameSurname = new JLabel ();
        nameSurname.setAlignmentX(Component.CENTER_ALIGNMENT);
        nameSurname.setBorder(BorderFactory.createEmptyBorder(20,0,0,0));
        JLabel reservationDates = new JLabel();
        reservationDates.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel roomNumber = new JLabel ();
        roomNumber.setAlignmentX(Component.CENTER_ALIGNMENT);
        nameSurname.setFont(new Font("serif",Font.BOLD,30));
        reservationDates.setFont(inputFont);
        roomNumber.setFont(inputFont);
        guestSurname = surnameOutField.getText(); 
        guestName = nameOutField.getText();
        JOptionPane.showMessageDialog(null, "Looking for guest");
        if (hotelData.findGuest(guestSurname,guestName)!=null){
            Guest foundGuest = hotelData.findGuest(guestSurname,guestName);
            nameSurname.setText(foundGuest.getName()+" "+foundGuest.getSurname());
            reservationDates.setText(foundGuest.getReservationDates());
            roomNumber.setText("Room: "+ foundGuest.getRoom().getRoomNumberInString());
            JPanel buttonPanel = new JPanel ();
            JButton yesButton = new JButton ("YES");
            yesButton.addActionListener(this);
            JButton noButton = new JButton ("NO");
            noButton.addActionListener(this);

            buttonPanel.setLayout(new GridLayout (0,2));
            buttonPanel.setBorder(BorderFactory.createEmptyBorder(40,0,0,0));

            question.setFont(mainFont);
            yesButton.setFont(mainFont);
            yesButton.setOpaque(true);
            yesButton.setBackground(new Color(150,204,138));
            noButton.setOpaque(true);
            noButton.setBackground(new Color(255,127,127));
            noButton.setFont(mainFont);

            buttonPanel.add(yesButton,gbc);
            buttonPanel.add(noButton,gbc);
            JPanel empty = new JPanel();
            empty.setSize(100,100);

            secondPanel.add(question);
            JPanel data = new JPanel ();
            data.setLayout(new BoxLayout(data, BoxLayout.Y_AXIS));
            data.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
            data.add(nameSurname);
            data.add(reservationDates);
            data.add(roomNumber);
            secondPanel.add(data);
            secondPanel.add(buttonPanel);
            secondPanel.add(empty);

            setContentPane(secondPanel);
            this.setBackground(new Color (82,199,64));
            revalidate();
        } else {
            JOptionPane.showMessageDialog(null,"Check out null pointer");
            getContentPane().removeAll();
            setFirstCheckOutWindowProperties ();
            setVisible(false);
            revalidate();
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        jb = (JButton)e.getSource();
        switch (jb.getActionCommand()) {
            case "NEXT":
                if (surnameOutField.getText().equals("")||surnameOutField.getText().equals("Input surname here")
                        ||nameOutField.getText().equals("")||nameOutField.getText().equals("Input surname here")){
                    JOptionPane.showMessageDialog(this, "Sorry. You have to input the surname to continue.","Cannot proceed",JOptionPane.INFORMATION_MESSAGE);
                    revalidate();
                    break;
                } else {
                    setSecondCheckOutWindowProperties();
                    break;
                }
            case "YES":
                hotelData.cancelReservation(guestSurname, guestName);
                setVisible(false);
                setFirstCheckOutWindowProperties();
                break;
            case "NO":
                JOptionPane.showMessageDialog(this, "Maybe you have misspelled the surname. Please try again", "Try again",JOptionPane.INFORMATION_MESSAGE);
                setFirstCheckOutWindowProperties ();
                break;
            default:
                break;
        }
    }
}
