package project;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;

public class CheckInWindow extends JFrame implements ActionListener {
    
    private JButton jb;
    private JComboBox <String> roomNumbersBox;
    private final Hotel hotelData;
    private final Font mainFont = new Font("serif", Font.PLAIN, 40);
    private final Font inputFont = new Font("serif", Font.PLAIN, 30);
    private final JTextField nameOfGuestField = new JTextField();
    private final JTextField surnameOfGuestField = new JTextField();
    private JFormattedTextField datecheckINField;
    private JFormattedTextField datecheckOUTField;
    private Guest newGuest;
    private ActionListenerComboBoxOfRooms alcb;
    private final MenuWindow mainGUI;
    private final Border paddingBorder;
    private final Date today;
    private final Date tomorrow;
    private final String [] comboBoxInfo;

    public CheckInWindow (MenuWindow mainGUI) throws HeadlessException {
        today = new Date();
        tomorrow= new Date();
        tomorrow.setDate(today.getDate()+1);
        this.paddingBorder = BorderFactory.createEmptyBorder(15, 0, 10, 15);
        this.mainGUI=mainGUI;
        this.hotelData=mainGUI.getHotel();
        this.alcb=null;
        comboBoxInfo=comboBoxInformation();
        addWindowProperties();
    }

    private void addWindowProperties() {
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        setSize (900,600);
        setLocationRelativeTo(null);
        setVisible(false);
        addCheckInWindowBody();
        setTitle("Check in guest");
    }

    private void addCheckInWindowBody() {
        getContentPane().removeAll();
        JPanel allPanel = new JPanel ();
        JPanel checkInWindowVariables = new JPanel();
        checkInWindowVariables.setLayout(new GridLayout(0, 2));
        allPanel.setLayout(new BoxLayout(allPanel, BoxLayout.Y_AXIS));
        

        JLabel nameOfGuestLabel = new JLabel("|||||| Name ||||||");
        nameOfGuestLabel.setFont(mainFont);
        nameOfGuestLabel.setHorizontalAlignment(SwingConstants.CENTER);
        nameOfGuestLabel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));

        JLabel surnameOfGuestLabel = new JLabel("|||||| Surname ||||||");
        surnameOfGuestLabel.setFont(mainFont);
        surnameOfGuestLabel.setHorizontalAlignment(SwingConstants.CENTER);
        surnameOfGuestLabel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));

        JLabel dateINLabel = new JLabel("|||||| Check in date ||||||");
        dateINLabel.setFont(mainFont);
        datecheckINField = new JFormattedTextField(today);
        dateINLabel.setHorizontalAlignment(SwingConstants.CENTER);
        dateINLabel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));

        JLabel dateOUTLabel = new JLabel("|||||| Check out date ||||||");
        dateOUTLabel.setFont(mainFont);
        datecheckOUTField = new JFormattedTextField(tomorrow);
        dateOUTLabel.setHorizontalAlignment(SwingConstants.CENTER);
        dateOUTLabel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        
        JLabel roomNumber = new JLabel ("|||||| Room ||||||");
        roomNumber.setFont(mainFont);
        roomNumber.setHorizontalAlignment(SwingConstants.CENTER);
        roomNumber.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));

        JButton nextButton = new JButton("NEXT");
        nextButton.addActionListener(this);
        nextButton.setFont(new Font("serif", Font.PLAIN, 30));
        
        JButton showAllButton = new JButton("SHOW ALL GUESTS");
        showAllButton.addActionListener(this);
        showAllButton.setFont(new Font("serif", Font.PLAIN, 30));


        nameOfGuestField.setFont(inputFont);
        nameOfGuestField.setForeground(Color.GRAY);
        
        surnameOfGuestField.setFont(inputFont);
        surnameOfGuestField.setForeground(Color.GRAY);  
        
        datecheckINField.setFont(inputFont);
        datecheckINField.setForeground(Color.GRAY);
        datecheckOUTField.setFont(inputFont);
        datecheckOUTField.setForeground(Color.GRAY);
        
        roomNumbersBox= new JComboBox <> (comboBoxInfo);
        alcb= new ActionListenerComboBoxOfRooms (roomNumbersBox, mainGUI);
        roomNumbersBox.addActionListener(alcb);
        
        JLabel furtherInstruction = new JLabel("Fill out information and proceed.");
        furtherInstruction.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        furtherInstruction.setAlignmentX(Component.LEFT_ALIGNMENT);

        checkInWindowVariables.add(nameOfGuestLabel);
        checkInWindowVariables.add(nameOfGuestField);
        checkInWindowVariables.add(surnameOfGuestLabel);
        checkInWindowVariables.add(surnameOfGuestField);
        checkInWindowVariables.add(dateINLabel);
        checkInWindowVariables.add(datecheckINField);
        checkInWindowVariables.add(dateOUTLabel);
        checkInWindowVariables.add(datecheckOUTField);
        checkInWindowVariables.add(roomNumber);
        checkInWindowVariables.add(roomNumbersBox);
        checkInWindowVariables.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        allPanel.add(checkInWindowVariables);
        allPanel.add(nextButton);
        allPanel.add(showAllButton);
        allPanel.add(furtherInstruction);
        setContentPane(allPanel);
        revalidate();
    }
    
    private String [] comboBoxInformation (){
        int arrayLength= hotelData.getRoomArray().length;
        String [] names= new String [arrayLength];
        Room [] tempRooms = hotelData.getRoomArray();
        for (int i=0;i<hotelData.getRoomArray().length;i++){
                names[i]="Room "+tempRooms[i].getRoomNumberInString()+" for "+tempRooms[i].getRoomFeeInString()+" PLN";
            }
        return names;
    }
    
    private void setCheckInfoPanel (){
        getContentPane().removeAll();
        JPanel allPanel = new JPanel ();
        allPanel.setLayout (new BoxLayout(allPanel,BoxLayout.Y_AXIS));
        JPanel questionPanel = new JPanel();
        questionPanel.setLayout (new FlowLayout());
        JPanel labelPanel = new JPanel ();
        labelPanel.setLayout(new GridLayout(0,2));
        JPanel buttonPanel = new JPanel ();
        buttonPanel.setLayout(new GridLayout(0,2));
        
        JLabel question = new JLabel ("<html><b>Is the information correct?</b><html>");
        question.setFont(inputFont);
        
        JLabel labelName= new JLabel ("Name:");
        labelName.setFont(inputFont);
        labelName.setHorizontalAlignment(SwingConstants.RIGHT);
        labelName.setBorder(paddingBorder);
        
        JLabel labelSurname = new JLabel ("Surname:");
        labelSurname.setFont(inputFont);
        labelSurname.setHorizontalAlignment(SwingConstants.RIGHT);
        labelSurname.setBorder(paddingBorder);
        
        JLabel labelsDateIn = new JLabel ("Check in date:");
        labelsDateIn.setFont(inputFont);
        labelsDateIn.setHorizontalAlignment(SwingConstants.RIGHT);
        labelsDateIn.setBorder(paddingBorder);
        
        JLabel labelsDateOut = new JLabel ("Check out date:");
        labelsDateOut.setFont(inputFont);
        labelsDateOut.setHorizontalAlignment(SwingConstants.RIGHT);
        labelsDateOut.setBorder(paddingBorder);
        
        JLabel roomLabel = new JLabel ("Room:");
        roomLabel.setFont(inputFont);
        roomLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        roomLabel.setBorder(paddingBorder);
        
        JLabel name = new JLabel (nameOfGuestField.getText());
        name.setFont(inputFont);
        name.setHorizontalAlignment(SwingConstants.LEFT);
        name.setBorder(paddingBorder);
        
        JLabel surname = new JLabel (surnameOfGuestField.getText());
        surname.setFont(inputFont);
        surname.setHorizontalAlignment(SwingConstants.LEFT);
        surname.setBorder(paddingBorder);

        JLabel dateIn = new JLabel (datecheckINField.getText());
        dateIn.setFont(inputFont);
        dateIn.setHorizontalAlignment(SwingConstants.LEFT);
        dateIn.setBorder(paddingBorder);

        JLabel dateOut = new JLabel (datecheckOUTField.getText());
        dateOut.setFont(inputFont);
        dateOut.setHorizontalAlignment(SwingConstants.LEFT);
        dateOut.setBorder(paddingBorder);
        
        JLabel room = new JLabel (alcb.getRoomNumberInString());
        room.setFont(inputFont);
        room.setHorizontalAlignment(SwingConstants.LEFT);
        room.setBorder(paddingBorder);

        JButton confirm = new JButton ("YES");
        confirm.addActionListener(this);
        JButton noButton = new JButton ("NO");
        noButton.addActionListener(this);
        
        labelPanel.add(labelName);
        labelPanel.add(name);
        labelPanel.add(labelSurname);
        labelPanel.add(surname);
        labelPanel.add(labelsDateIn);
        labelPanel.add(dateIn);
        labelPanel.add(labelsDateOut);
        labelPanel.add(dateOut);
        labelPanel.add(roomLabel);
        labelPanel.add(room);
        
        questionPanel.add(question);
        allPanel.add(labelPanel);
        allPanel.add(question);
        buttonPanel.add(confirm);
        buttonPanel.add(noButton);
        allPanel.add(buttonPanel);
        setContentPane(allPanel);
        revalidate();
    }
    
    private Date getDate (JFormattedTextField field){
        Date startDate = (Date)field.getValue();
        return startDate;
    }
    
    private boolean isCheckInDatebeforeCheckOutDate (Date date1, Date date2){
        return !(date2.compareTo(date1)==0|| date2.compareTo(date1)<0);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        jb= (JButton)e.getSource();
        switch (jb.getActionCommand()) {
            case "NEXT":
                    if (nameOfGuestField.getText().isEmpty() || surnameOfGuestField.getText().isEmpty()){
                    JOptionPane.showMessageDialog(this, "Please fill all spaces with valid information to proceed.", "System cannot check in guest!", JOptionPane.ERROR_MESSAGE);
                } else 
                    if (isCheckInDatebeforeCheckOutDate(getDate(datecheckINField),getDate(datecheckOUTField))==false){
                        JOptionPane.showMessageDialog(this, "Check in date must be before check out date.","System cannot check in guest!",JOptionPane.ERROR_MESSAGE);
                    } else
                        setCheckInfoPanel();
                        break;          
            case "SHOW ALL GUESTS":
                JOptionPane.showMessageDialog(this, hotelData.showGuestsByRoom(), "Guests in the hotel", JOptionPane.INFORMATION_MESSAGE);
                break;
            case "YES":
                this.newGuest = new Guest (nameOfGuestField.getText(),surnameOfGuestField.getText());
                newGuest.setReservationDates(getDate(datecheckINField), getDate(datecheckOUTField));
                newGuest.getCheckInDate().setHours(12);
                newGuest.getCheckInDate().setMinutes(0);
                newGuest.getCheckInDate().setSeconds(0);
                newGuest.getCheckOutDate().setHours(10);
                newGuest.getCheckOutDate().setMinutes(0);
                newGuest.getCheckOutDate().setSeconds(0);
                if (alcb.returnTheRoom().addGuestToRoom(newGuest)){
                    hotelData.addGuest(newGuest);
                    newGuest.addRoomToGuest(alcb.returnTheRoom());  
                    JOptionPane.showMessageDialog(this, "The guest has been checked in", "Successful check in", JOptionPane.INFORMATION_MESSAGE);
                }
                setVisible(false);
                addCheckInWindowBody();
                nameOfGuestField.setText("");
                surnameOfGuestField.setText("");
                break;
            case "NO":
                addCheckInWindowBody();
                break;
            default:
                break;
        }
    }
}    
