package project;

import java.io.Serializable;
import javax.swing.JOptionPane;

public class GuestsInRoomListChronologically implements Serializable{
    
    private Node head;
    private Node tail;
    
    public GuestsInRoomListChronologically (){    
        head=null;
        tail=null;
    }
    public boolean add (Guest nGuest){
        Node current=head;
        if (head==null){
            head = new Node(nGuest);
            tail=head;
            return true;
        }
        if (head.getGuest().getCheckInDate().compareTo(nGuest.getCheckInDate())==0){
            return false;
        }
        if (nGuest.getCheckOutDate().compareTo(head.getGuest().getCheckInDate())<=0){
            Node temp = head;
            head= new Node(nGuest,temp);
            return true;
        }
        if (nGuest.getCheckInDate().compareTo(tail.getGuest().getCheckOutDate())>=0){
            if (head==tail){
                head.setNext(new Node(nGuest));
                tail=head.getNext();

            } else {
                Node newGuest = new Node (nGuest);
                tail.setNext(newGuest);
                tail=newGuest;
            }
            return true;
        }
        while (current.getNext()!=null&&
                nGuest.getCheckInDate().compareTo(current.getNext().getGuest().getCheckOutDate())>=0){
                current=current.getNext();
        }
        if (nGuest.getCheckOutDate().compareTo(current.getNext().getGuest().getCheckInDate())<=0&&
                current.getGuest().getCheckOutDate().compareTo(nGuest.getCheckInDate())<=0){
            JOptionPane.showMessageDialog(null, nGuest.getCheckOutDate());
            JOptionPane.showMessageDialog(null, current.getNext().getGuest().getCheckInDate());
            Node newGuest = new Node (nGuest);        
            newGuest.setNext(current.getNext());
            current.setNext(newGuest);
            return true;
        }
        return false;
            
    }

    public Guest remove (String surname, String name){
        Node foundGuest= findGuest(surname,name);
        Guest result=null;
        if (foundGuest==null){
            return result;
        }
        if (head==foundGuest){
            if (head.getNext()==null){
                result = head.getGuest();
                head=null;
                return result;
            } else {
                result = head.getGuest();
                head=head.getNext();
                return result;
            }
        } else {
            Node current=head;
            while(current.getNext()!=foundGuest){
                current=current.getNext();
            }
            result = current.getNext().getGuest();
            current.setNext(current.getNext().getNext());
            return result;
        }
    }
    
    private Node findGuest (String surname, String name){
        Node current= head;
        while(current!=null){
            if (current.getGuest().getSurname().equalsIgnoreCase(surname)&&
                    current.getGuest().getName().equalsIgnoreCase(name)){
                return current;
            } 
            current=current.getNext();
        }
        return null;
    }
    
    public String toStringWithoutRoomNumber (){
        String result="";
        if (head==null){
            result = "No guests to show\n";
        } else {
            Node temp=head;
            while (temp!=null){                
                result= result + temp.getGuest().getName() + " " + temp.getGuest().getSurname()
                    + " "+ temp.getGuest().getReservationDates()+
                        " Fee: "+temp.getGuest().getFee()+"PLN\n";
                temp=temp.getNext();
            }
        }
        return result;
    }
    
    @Override
    public String toString (){
        String result="";
        Node temp=head;
        while (temp!=null){
            result= result + temp.getGuest().showGuestInfo() + "\n";
            temp=temp.next;
        }
        return result;
    }
}
